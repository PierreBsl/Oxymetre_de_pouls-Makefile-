#include "define.h"

void integrationTest(char* filename);
