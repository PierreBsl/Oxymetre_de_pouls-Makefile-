#include "integration.h"

int main() {
    integrationTest("record1_bin.dat");
}
