#include "define.h"

absorp iirTest(char* filename);
absorp iir(absorp myAbsorp, param_iir* preAbsorp);
void init_iir(param_iir* pre_absorp);