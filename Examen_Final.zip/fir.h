#include "define.h"

absorp firTest(char* filename);
absorp fir(absorp myAbsorS, param_fir * cpt);
void init_fir(param_fir * cpt);
