#include "define.h"

oxy mesureTest(char* filename);
oxy mesure(absorp myAbsorp, param_mesure* ech, oxy myOxy);
void init_mesure(param_mesure* ech);

	
